# Engineering standards

Entrypoints compose. Features own behavior; no feature imports another feature's internals. Pure domain code cannot access Chrome, DOM, storage or network. Side effects belong in narrow adapters. Shared UI contains no feature business logic. No cycles, generic event buses, mutable global namespaces or miscellaneous utils buckets.

TypeScript uses strict, noUncheckedIndexedAccess and exactOptionalPropertyTypes. Validate external input at runtime. Preserve edits on errors. Validate migrations before writing and keep rollback data. Never sync secrets or log sensitive content.

Legacy migration exceptions name exact files, their reason and removal milestone. New code cannot inherit legacy exemptions.

Use behavior tests, including races and failure recovery. Each stage needs a separate review pass. Measure performance before optimizing. CI checks types, lint, boundaries, cycles, unused code, tests and packaged builds.
