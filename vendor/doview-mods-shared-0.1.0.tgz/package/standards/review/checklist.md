# Review checklist

- Correct feature ownership and dependency direction?
- Existing user behavior and data preserved?
- Runtime validation and minimal permissions?
- Safe during suspension, concurrent writes, teardown and navigation?
- Observers, queries, storage writes bounded and necessary?
- Actionable errors without sensitive logs?
- Meaningful race and failure tests?
- Performance measured under documented conditions?

Investigate repeated latency regressions exceeding both 20% and 20ms. Do not add complexity to optimize noise. Record validation and outstanding risks in each review.
