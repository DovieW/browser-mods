# Chrome extension architecture

Register worker listeners synchronously. Persist necessary state across suspension. No artificial keepalive or idle polling. Worker imports are static; extension-page feature views can load lazily.

Content scripts run only for enabled features with granted access. Teardown observers/listeners/timers. MAIN-world messages are untrusted. Validate sender, frame ownership, schema and capability at privileged boundaries.

Request permissions inside the user gesture. Never automatically retry non-idempotent remote operations. Separate regular/incognito context. Coalesce tab changes and storage writes. Avoid whole-document rescans on every mutation. Distinguish local save success from sync delivery.

Test worker restart, popup closure, navigation, permission denial/revocation and frame replacement in disposable profiles.
