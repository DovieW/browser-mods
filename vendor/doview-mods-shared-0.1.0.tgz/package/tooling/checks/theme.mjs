import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root=new URL('../../',import.meta.url);
const tokens=JSON.parse(readFileSync(new URL('design/tokens/github-dark-default.json',root)));
const css=readFileSync(new URL('design/styles/tokens.css',root),'utf8');
for(const [key,value] of Object.entries(tokens)) assert.ok(css.includes(`--mods-${key}: ${value};`),`Theme drift: ${key}`);
console.log('Theme tokens match CSS');
