Start with public.ts, pure domain logic and colocated tests. Add application/, adapters/ and ui/ only when needed. Register actions at composition. Document state, permissions and teardown.
