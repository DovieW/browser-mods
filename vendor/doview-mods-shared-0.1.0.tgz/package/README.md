# Dovie's Mods Shared

Shared standards, design and tooling for personal Mods projects. Optimize noticeable latency and idle work, not measurement noise.

Consume an exact Git revision as `@doview/mods-shared`. No remote runtime assets. Theme colors match GitHub VS Code theme 6.3.5 (MIT), https://github.com/primer/github-vscode-theme.

`standards/` owns rules; `design/` owns semantic theme tokens; `tooling/` enforces rules; `templates/` provides starting points. Browser business logic belongs in the consuming application.

Run `npm test`. Upgrade shared dependencies deliberately.
